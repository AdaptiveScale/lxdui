__version__ = "1.0.1"
__giturl__ = "https://gitlab.com/jeton/lxd-app-ci.git"